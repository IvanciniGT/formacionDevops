/**
 * 
 */
package pagecode.layout;

import pagecode.PageCodeBase;

/**
 * @author vtriquell
 *
 */
public class LoginLayout extends PageCodeBase {

}