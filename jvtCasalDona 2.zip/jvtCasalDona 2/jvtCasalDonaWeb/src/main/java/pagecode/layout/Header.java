/**
 * 
 */
package pagecode.layout;

import pagecode.PageCodeBase;

/**
 * @author vtriquell
 *
 */
public class Header extends PageCodeBase {

}