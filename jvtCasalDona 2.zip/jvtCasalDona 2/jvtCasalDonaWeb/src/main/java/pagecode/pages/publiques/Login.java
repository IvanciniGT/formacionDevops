/**
 * 
 */
package pagecode.pages.publiques;

import pagecode.PageCodeBase;

/**
 * @author vtriq
 *
 */
public class Login extends PageCodeBase {

}